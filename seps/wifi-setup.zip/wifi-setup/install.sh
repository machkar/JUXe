#!/bin/sh
sudo apt-get install bridge-utils hostapd isc-dhcp-client
